function openChangeName() {

    var toggle = document.getElementById("settings-changingname");

    if (toggle) {
        toggle.classList.toggle("settings-changingname");
    }

}

function openChangeUserName() {

    var toggle = document.getElementById("settings-changingusername");

    if (toggle) {
        toggle.classList.toggle("settings-changingusername");
    }

}

function openChangePass() {

    var toggle = document.getElementById("settings-changingpass");

    if (toggle) {
        toggle.classList.toggle("settings-changingpass");
    }

}

function openChangePfp() {

    var toggle = document.getElementById("settings-changingprofilepic");

    if (toggle) {
        toggle.classList.toggle("settings-changingprofilepic");
    }

}

function openChangeDescription() {

    var toggle = document.getElementById("settings-changingdesc");

    if (toggle) {
        toggle.classList.toggle("settings-changingdesc");
    }

}